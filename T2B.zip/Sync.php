<!--Page starts here-->

<?php
require_once("Header.php");

?>
				<div class='eList' >
					<?php echo "Sync";
						  sleep(5);
					?>
				</div>
				<div class='eList' >
				<?php echo "it";
						  sleep(5);
					?>
				</div>
				<div class='eList' >
				<?php echo "pls";
						  sleep(5);
					?>
				</div>
				<div class='eList' >
				</div>
				<div class='eList' >
				</div>
			</div>
		</div>
	</body>
</html>